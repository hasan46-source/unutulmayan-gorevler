---
name: "nasa-web-sitesi"
description: "NASA'nın terk edilmiş ama unutulmamış Ay ve Mars araştırmaları hakkında herkesin girebileceği web sitesi projesi"
---

- herkesin girebileceği bir web sitesi istiyor
- konu: NASA ile ilgili, terk edilmiş ama unutulmamış Ay ve Mars uzay araştırmaları
- site adı "Unutulmayan Görevler"; sitenin adresi değişmesin, mevcut yayınlanmış sayfa güncellensin
- istedikleri: her görev kartına tıklayınca konu hakkında uzun ve doğru bilgi; Ay seçilince fareyle döndürülebilen Ay (kraterler, üsler, uzay araçları); istatistik kutuları yerine yalnızca bu site hakkında soru cevaplayan yapay zeka sohbeti
